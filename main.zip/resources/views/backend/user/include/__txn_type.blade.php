<div class="site-badge primary">{{ ucfirst($type) }}</div>
