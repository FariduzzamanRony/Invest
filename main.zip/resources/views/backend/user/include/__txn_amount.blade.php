<strong
    class="{{$type !== 'subtract' ? 'green-color': 'red-color'}}">{{ ($type !== 'subtract' ? '+': '-' ).$final_amount.' '.$currency }}</strong>
