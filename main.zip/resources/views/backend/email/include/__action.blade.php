<a href="{{ route('admin.email-template-edit',$id) }}" class="round-icon-btn primary-btn" data-bs-toggle="tooltip"
   title="Edit Email Template" data-bs-original-title="Edit Email Template"><i icon-name="edit-3"></i></a>
<script>
   'use strict';
   lucide.createIcons();
</script>
