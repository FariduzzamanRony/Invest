<div class="modal fade" id="editNavMenu" tabindex="-1" aria-labelledby="editNavMenuModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered">
        <div class="modal-content site-table-modal">
            <div class="modal-body popup-body">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                <div class="popup-body-text edit-section">

                </div>

            </div>
        </div>
    </div>
</div>
