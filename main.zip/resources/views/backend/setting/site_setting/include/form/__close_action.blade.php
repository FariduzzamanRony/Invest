<div class="row">
    <div class="offset-sm-4 col-sm-8">
        <button
            type="submit"
            class="site-btn-sm primary-btn w-100">
            {{ __('Save Changes') }}
        </button>
    </div>
</div>
</form>
