<a href="{{ route('admin.user.edit',$id) }}" class="link">{{ $username }}</a>
