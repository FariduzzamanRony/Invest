<strong> {{ $schema['name'] }} <i icon-name="arrow-big-right"></i> {{ $currencySymbol.$invest_amount }}
    <span class="invested-amount">{{ $created_at  }}</span>
</strong>

<script>
    'use strict';
    lucide.createIcons();
</script>
