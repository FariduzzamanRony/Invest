<strong>
    {{ $interest_type == 'percentage' ? $interest.'%' : $currencySymbol.$interest }}
</strong>

