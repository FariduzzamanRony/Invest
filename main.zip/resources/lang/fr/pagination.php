<?php

return array(
    'next' => 'Suivant &raquo;Le mot de passe fourni est incorrect',
    'previous' => '&laquo; Précédent',
);
