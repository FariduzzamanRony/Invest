<?php

return array(
    'failed' => 'Estas credenciales no coinciden con nuestros registros',
    'password' => 'La contraseña es incorrecta',
    'throttle' => 'Demasiados intentos de inicio de sesión. Vuelva a intentarlo en :segundos segundos.',
);
