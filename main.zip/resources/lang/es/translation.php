<?php

return array(
    'key' => 'llave',
);
